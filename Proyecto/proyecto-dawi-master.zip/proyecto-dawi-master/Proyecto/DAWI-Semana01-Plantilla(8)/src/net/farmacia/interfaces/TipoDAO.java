package net.farmacia.interfaces;

import java.util.List;

import net.farmacia.entidad.Tipo;

public interface TipoDAO {
	public List<Tipo> listAllAtLaboratorio(int idLab);
	
}
