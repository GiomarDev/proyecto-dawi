package net.farmacia.entidad;

public class Enlace {
	private int idEnlace;
	private String descripcion,ruta;
	
	
	public int getIdEnlace() {
		return idEnlace;
	}
	public void setIdEnlace(int idEnlace) {
		this.idEnlace = idEnlace;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getRuta() {
		return ruta;
	}
	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	
	
	
}
